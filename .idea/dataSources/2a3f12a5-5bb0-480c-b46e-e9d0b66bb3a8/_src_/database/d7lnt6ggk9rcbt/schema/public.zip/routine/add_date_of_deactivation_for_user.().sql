CREATE FUNCTION add_date_of_deactivation_for_user () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
    IF OLD.is_deactivated = false AND NEW.is_deactivated = true THEN
        NEW.date_of_deactivation := now();
    ELSIF OLD.is_deactivated = true AND NEW.is_deactivated = false THEN
        NEW.date_of_deactivation := NULL;
    END IF;
    RETURN NEW;
END;
$$
