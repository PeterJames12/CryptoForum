CREATE FUNCTION doo (date) RETURNS integer
	LANGUAGE plpgsql
AS $$
DECLARE r INT;
BEGIN
  LOOP
    --   SELECT count(r.id) AS count
    --   FROM request r  WHERE r.date_of_creation:: DATE BETWEEN a:: DATE AND a :: DATE + INTERVAL '1 month';
    EXIT WHEN r = 3;  -- same result as previous example
  END LOOP;
  RETURN 1;
END;
$$
