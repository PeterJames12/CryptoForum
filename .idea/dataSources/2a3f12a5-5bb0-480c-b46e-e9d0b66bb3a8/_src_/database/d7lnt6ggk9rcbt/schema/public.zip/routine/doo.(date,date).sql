CREATE FUNCTION doo (a date, b date) RETURNS void
	LANGUAGE plpgsql
AS $$
-- DECLARE r INT;
BEGIN
--   r = 0;
--   LOOP
    SELECT *
    FROM request r
    WHERE r.progress_status_id=8;
--     EXIT WHEN r = 2; -- same result as previous example
--   r = r + 1;
--   END LOOP;
  --   SELECT count(r.id) AS count
  --   FROM request r
  --   WHERE r.date_of_creation BETWEEN $1 AND $2;
END;
$$
