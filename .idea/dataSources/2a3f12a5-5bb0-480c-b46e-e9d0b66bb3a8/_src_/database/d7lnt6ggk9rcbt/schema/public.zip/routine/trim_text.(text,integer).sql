CREATE FUNCTION trim_text (s text, max_count_of_chars integer) RETURNS text
	LANGUAGE plpgsql
AS $$
DECLARE result text;
BEGIN
  result = substring(s from 1 for max_count_of_chars);
  IF(length(s) > max_count_of_chars) THEN
    result = result || '...';
  END IF;
  RETURN result;
END;
$$
