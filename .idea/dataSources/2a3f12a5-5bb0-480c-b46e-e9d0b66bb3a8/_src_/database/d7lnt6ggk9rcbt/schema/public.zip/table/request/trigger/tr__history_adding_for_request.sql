CREATE TRIGGER tr__history_adding_for_request
AFTER UPDATE ON request
FOR EACH ROW EXECUTE PROCEDURE add_history_record_for_request()