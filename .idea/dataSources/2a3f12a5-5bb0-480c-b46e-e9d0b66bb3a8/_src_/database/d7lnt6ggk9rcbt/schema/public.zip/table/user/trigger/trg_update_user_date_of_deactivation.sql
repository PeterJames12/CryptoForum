CREATE TRIGGER trg_update_user_date_of_deactivation
BEFORE UPDATE ON "user"
FOR EACH ROW EXECUTE PROCEDURE add_date_of_deactivation_for_user()